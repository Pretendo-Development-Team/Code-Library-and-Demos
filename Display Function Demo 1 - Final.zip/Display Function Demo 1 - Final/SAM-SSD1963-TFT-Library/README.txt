This is a software driver for the Solomon Systech SSD1963 display controller to be used in 
conjunction with Atmel SAM MCU's and the ASF. This driver is a student work-in-progress, 
and is incomplete, untested, and potentially unstable as March 7, 2017. Feel free to 
re-use this code as you see fit. 

List of ASF dependencies:
-IOPORT